from Business import Business
from User import User

'''
Import to run the Server1 file before running the Runfile
'''

def main():
    print("Run Server1 file before running this file.")
    B = Business()
    U = User()


if __name__ == "__main__":
    main()
