from GUI import GUI
from Server1 import Server

class User:
    def __init__(self):
        self.G = GUI()